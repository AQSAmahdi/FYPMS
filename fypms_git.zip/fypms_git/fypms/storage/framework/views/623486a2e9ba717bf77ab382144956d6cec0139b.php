<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Phase Evaluation - FYPMS</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:#f0f4f8;min-height:100vh}
.main{margin-left:260px;padding:28px 32px}
.topbar{background:linear-gradient(135deg,#378ADD,#0C447C);border-radius:12px;padding:18px 26px;margin-bottom:22px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 1px 12px rgba(12,68,124,.15)}
.topbar h2{color:#fff;font-size:18px;font-weight:700}
.topbar p{color:rgba(255,255,255,.8);font-size:12px;margin-top:2px}
.badge-role{background:rgba(255,255,255,.2);color:#fff;padding:5px 14px;border-radius:20px;font-size:12px;font-weight:600;border:1px solid rgba(255,255,255,.4)}
.card{background:#fff;border-radius:12px;padding:22px;box-shadow:0 1px 12px rgba(12,68,124,.07);border:1px solid #e8f0f9;margin-bottom:20px}
.card h3{color:#0C447C;font-size:15px;font-weight:700;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid #e8f0f9}
.alert-success{background:#dcfce7;color:#166534;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:13px;border:1px solid #bbf7d0}
.alert-error{background:#fef2f2;color:#b91c1c;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:13px}
.filter-tabs{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap}
.filter-tab{background:#fff;border:1px solid #d5e3f0;color:#5a7a9a;border-radius:20px;padding:8px 18px;font-size:12.5px;font-weight:600;cursor:pointer;transition:all .15s;font-family:'Segoe UI',sans-serif}
.filter-tab:hover{border-color:#0C447C;color:#0C447C}
.filter-tab.active{background:#0C447C;color:#fff;border-color:#0C447C}
.group-section{margin-bottom:28px}
.group-section-title{display:flex;align-items:center;gap:10px;color:#0C447C;font-size:14px;font-weight:700;margin-bottom:14px;padding-bottom:8px;border-bottom:2px solid #e8f0f9}
.group-section-title::before{content:'';width:4px;height:16px;background:#0C447C;border-radius:3px;display:inline-block}
.group-section-title{cursor:pointer;user-select:none}
.chevron{font-size:12px;color:#0C447C}
.group-count-badge{margin-left:auto;font-size:11px;font-weight:600;color:#8096b0;background:#f4f8fd;padding:3px 10px;border-radius:12px}
.group-body{overflow:hidden}
.search-box-wrap{margin-bottom:16px}
.group-search{width:100%;max-width:340px;padding:10px 16px;border:1px solid #d5e3f0;border-radius:10px;font-size:13px;outline:none;font-family:'Segoe UI',sans-serif;background:#fff;transition:border .15s}
.group-search:focus{border-color:#0C447C}
.phase-card{border:1.5px solid #e8f0f9;border-radius:10px;padding:18px;margin-bottom:16px;transition:all .2s;background:#fff;box-shadow:0 1px 8px rgba(12,68,124,.05)}
.phase-card:hover{border-color:#0C447C;box-shadow:0 2px 12px rgba(12,68,124,.08)}
.phase-card[data-status="open"]{border-left:4px solid #16a34a}
.phase-card[data-status="upcoming"]{border-left:4px solid #ca8a04}
.phase-card[data-status="closed"]{border-left:4px solid #94a3b8}
.phase-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px}
.phase-name{font-size:16px;font-weight:700;color:#0C447C}
.phase-meta{font-size:12px;color:#8096b0;margin-top:3px}
.badge-open{background:#dcfce7;color:#166534;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600}
.badge-closed{background:#fef2f2;color:#b91c1c;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600}
.badge-upcoming{background:#fef9c3;color:#854d0e;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600}
.badge-submitted{background:#e0e7ff;color:#3730a3;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600}
.date-row{display:flex;gap:12px;margin-bottom:14px;flex-wrap:wrap}
.date-box{background:#f4f8fd;border-radius:8px;padding:8px 14px;flex:1;min-width:130px}
.date-box .lbl{font-size:10px;color:#8096b0;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px}
.date-box .val{font-size:13px;font-weight:600;color:#0C447C}
.students-table{width:100%;border-collapse:collapse;font-size:13px;margin-top:10px}
.students-table th{background:#f4f8fd;color:#0C447C;font-weight:700;padding:9px 12px;text-align:left;border-bottom:2px solid #e8f0f9}
.students-table td{padding:9px 12px;border-bottom:1px solid #f0f4f8;vertical-align:middle}
.students-table tr:hover td{background:#f8fafd}
.mark-input{width:80px;padding:6px 10px;border:1.5px solid #e8f0f9;border-radius:6px;font-size:13px;text-align:center;outline:none;transition:border .2s}
.mark-input:focus{border-color:#0C447C}
.mark-input:disabled{background:#f4f8fd;color:#8096b0}
.btn-submit{background:#0C447C;color:#fff;border:none;padding:9px 22px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;margin-top:14px}
.btn-submit:hover{background:#185FA5}
.btn-submit:disabled{background:#8096b0;cursor:not-allowed}
.total-badge{display:inline-block;background:#e8f0f9;color:#0C447C;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600;margin-left:8px}
.empty{text-align:center;padding:30px;color:#8096b0;font-size:14px}
.no-schedule{background:#fef9c3;border:1px solid #fde68a;border-radius:8px;padding:12px 16px;font-size:13px;color:#854d0e;margin-top:10px}
@media(max-width:768px){
  .main{margin-left:0;padding:16px}
  .topbar{flex-direction:column;align-items:flex-start;gap:8px}
  .date-row{flex-direction:column}
  .mark-input{width:70px}
}
</style>
</head>
<body>
<?php echo $__env->make('faculty.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main">
  <div class="topbar">
    <div>
      <h2>Phase Evaluation</h2>
      <p>Submit marks for your assigned students</p>
    </div>
    <span class="badge-role">Faculty</span>
  </div>

  <?php if(session('success')): ?>
    <div class="alert-success">✓ <?php echo e(session('success')); ?></div>
  <?php endif; ?>
  <?php if($errors->any()): ?>
    <div class="alert-error"><?php echo e($errors->first()); ?></div>
  <?php endif; ?>

  <?php if($schedules->count() > 0): ?>

    <?php
      $today = now();
      $schedulesSorted = $schedules->map(function($schedule) use ($today) {
          $scheduledDate = \Carbon\Carbon::parse($schedule->schedule_date)->startOfDay();
          $windowEnd     = $scheduledDate->copy()->addDays(2)->endOfDay();

          if ($schedule->status === 'completed') {
              $computedStatus = 'closed';
          } elseif ($today->lt($scheduledDate)) {
              $computedStatus = 'upcoming';
          } elseif ($today->gt($windowEnd)) {
              $computedStatus = 'closed';
          } else {
              $computedStatus = 'open';
          }
          $schedule->computed_status = $computedStatus;
          return $schedule;
      })->sortBy(function($s){
          return ['open' => 0, 'upcoming' => 1, 'closed' => 2][$s->computed_status] ?? 3;
      });

      $openCount     = $schedulesSorted->where('computed_status','open')->count();
      $upcomingCount = $schedulesSorted->where('computed_status','upcoming')->count();
      $closedCount   = $schedulesSorted->where('computed_status','closed')->count();

      $groupedSchedules = $schedulesSorted->groupBy(function($s){
          return $s->group->group_code ?? ('Group #'.$s->group_id);
      });
    ?>

    <div class="search-box-wrap">
      <input type="text" id="groupSearch" class="group-search" placeholder="🔍 Search by group..." oninput="searchGroups(this.value)" spellcheck="false" autocomplete="off">
    </div>

    <div class="filter-tabs">
      <button class="filter-tab active" data-filter="all" onclick="filterPhases('all',this)">All (<?php echo e($schedulesSorted->count()); ?>)</button>
      <button class="filter-tab" data-filter="open" onclick="filterPhases('open',this)">🟢 Action Needed (<?php echo e($openCount); ?>)</button>
      <button class="filter-tab" data-filter="upcoming" onclick="filterPhases('upcoming',this)">🟡 Not Started (<?php echo e($upcomingCount); ?>)</button>
      <button class="filter-tab" data-filter="closed" onclick="filterPhases('closed',this)">✅ Completed (<?php echo e($closedCount); ?>)</button>
    </div>

    <?php $__currentLoopData = $groupedSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupCode => $groupSchedules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $groupHasOpen = $groupSchedules->contains('computed_status','open'); ?>
    <div class="group-section" data-group-code="<?php echo e(strtolower($groupCode)); ?>">
      <div class="group-section-title" onclick="toggleGroup(this)">
        <span class="chevron"><?php echo e($groupHasOpen ? '▾' : '▸'); ?></span>
        <?php echo e($groupCode); ?>

        <span class="group-count-badge"><?php echo e($groupSchedules->count()); ?> <?php echo e($groupSchedules->count()==1 ? 'phase' : 'phases'); ?></span>
      </div>
      <div class="group-body" style="display:<?php echo e($groupHasOpen ? 'block' : 'none'); ?>">

      <?php $__currentLoopData = $groupSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $status = $schedule->computed_status; ?>

      <div class="phase-card" data-status="<?php echo e($status); ?>">
      <div class="phase-header">
        <div>
          <div class="phase-name">
            <?php echo e($schedule->phase->name ?? 'N/A'); ?>

            <span class="total-badge">Total: <?php echo e($schedule->phase->total_marks ?? '—'); ?> marks</span>
          </div>
          <div class="phase-meta">
            Group: <?php echo e($schedule->group->group_code ?? 'Group '.$schedule->group_id); ?>

            <?php if($schedule->group->project_title): ?>
              &bull; <?php echo e($schedule->group->project_title); ?>

            <?php endif; ?>
            <?php if($schedule->venue): ?> &bull; 📍 <?php echo e($schedule->venue); ?> <?php endif; ?>
          </div>
        </div>
        <span class="badge-<?php echo e($status); ?>">
          <?php if($status === 'open'): ?> 🟢 Action Needed
          <?php elseif($status === 'upcoming'): ?> 🟡 Not Started Yet
          <?php else: ?> ✅ Completed
          <?php endif; ?>
        </span>
      </div>

      <div class="date-row">
        <div class="date-box">
          <div class="lbl">Scheduled</div>
          <div class="val"><?php echo e(\Carbon\Carbon::parse($schedule->schedule_date)->format('d M Y')); ?> <?php echo e($schedule->schedule_time ?? ''); ?></div>
        </div>
        <?php if($schedule->notes): ?>
        <div class="date-box" style="flex:2">
          <div class="lbl">Notes</div>
          <div class="val" style="font-weight:400;color:#5a7a9a"><?php echo e($schedule->notes); ?></div>
        </div>
        <?php endif; ?>
      </div>

      <?php if($status === 'open'): ?>
        <form method="POST" action="<?php echo e(route('faculty.phase-evaluation.store')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="phase_id"    value="<?php echo e($schedule->phase_id); ?>">
          <input type="hidden" name="group_id"    value="<?php echo e($schedule->group_id); ?>">
          <input type="hidden" name="schedule_id" value="<?php echo e($schedule->id); ?>">

          <table class="students-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Student Name</th>
                <th>Roll Number</th>
                <th>Marks <span style="font-weight:400;color:#8096b0">(out of <?php echo e($schedule->phase->total_marks ?? '—'); ?>)</span></th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $schedule->group->members ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php
                $existingMark = $marks->where('student_id', $student->user_id)
                                      ->where('phase_id', $schedule->phase_id)
                                      ->first();
              ?>
              <tr>
                <td><?php echo e($i+1); ?></td>
                <td style="font-weight:600;color:#1e3a5f"><?php echo e($student->user->name ?? "N/A"); ?></td>
                <td style="color:#8096b0"><?php echo e($student->user->studentProfile->student_id ?? "—"); ?></td>
                <td>
                  <input type="hidden" name="students[<?php echo e($i); ?>][student_id]" value="<?php echo e($student->user_id); ?>">
                  <input type="number"
                    class="mark-input"
                    name="students[<?php echo e($i); ?>][marks]"
                    min="0"
                    max="<?php echo e($schedule->phase->total_marks ?? 100); ?>"
                    value="<?php echo e($existingMark->marks_obtained ?? ''); ?>"
                    placeholder="0"
                    <?php echo e($existingMark ? 'disabled' : ''); ?>>
                </td>
                <td>
                  <?php if($existingMark): ?>
                    <span class="badge-submitted">✓ Submitted (<?php echo e($existingMark->obtained_marks); ?>)</span>
                  <?php else: ?>
                    <span style="font-size:12px;color:#8096b0">Pending</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="empty">No students in this group.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>

          <?php if(($schedule->group->members ?? collect())->count() > 0): ?>
            <?php $allSubmitted = true;
              foreach(($schedule->group->members ?? []) as $st) {
                if(!$marks->where('student_id',$st->user_id)->where('phase_id',$schedule->phase_id)->first())
                  $allSubmitted = false;
              }
            ?>
            <?php if(!$allSubmitted): ?>
              <button type="submit" class="btn-submit">📤 Submit Marks</button>
            <?php else: ?>
              <button type="button" class="btn-submit" disabled>✓ All Marks Submitted</button>
            <?php endif; ?>
          <?php endif; ?>
        </form>

      <?php elseif($status === 'upcoming'): ?>
        <div class="no-schedule">⏳ Evaluation not started yet. Opens on <?php echo e(\Carbon\Carbon::parse($schedule->schedule_date)->format('d M Y')); ?> <?php echo e($schedule->schedule_time ?? ''); ?></div>
      <?php else: ?>
        <div class="no-schedule" style="background:#f4f8fd;border-color:#d5e3f0;color:#5a7a9a">
          ✅ Evaluation completed on <?php echo e(\Carbon\Carbon::parse($schedule->schedule_date)->format('d M Y')); ?>

        </div>
      <?php endif; ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
    <div class="card">
      <div class="empty">📭 No phase schedules assigned to you yet.</div>
    </div>
  <?php endif; ?>
</div>

<script>
function toggleSidebar(){
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('overlay')?.classList.toggle('show');
}

function filterPhases(status, btn){
    document.querySelectorAll('.filter-tab').forEach(function(t){ t.classList.remove('active'); });
    btn.classList.add('active');

    document.querySelectorAll('.group-section').forEach(function(section){
        var anyVisible = false;
        section.querySelectorAll('.phase-card').forEach(function(card){
            var show = (status === 'all' || card.getAttribute('data-status') === status);
            card.style.display = show ? '' : 'none';
            if(show) anyVisible = true;
        });
        section.style.display = anyVisible ? '' : 'none';

        // Every tab switch resets every group back to collapsed,
        // regardless of what was open before. User must click to reopen.
        var body = section.querySelector('.group-body');
        if(body) body.style.display = 'none';
        var chevron = section.querySelector('.chevron');
        if(chevron) chevron.textContent = '▸';
    });
}

function toggleGroup(titleEl){
    var body = titleEl.nextElementSibling;
    var chevron = titleEl.querySelector('.chevron');
    if(body.style.display === 'none'){
        body.style.display = 'block';
        if(chevron) chevron.textContent = '▾';
    } else {
        body.style.display = 'none';
        if(chevron) chevron.textContent = '▸';
    }
}

function searchGroups(query){
    query = query.toLowerCase().trim();
    document.querySelectorAll('.group-section').forEach(function(section){
        var code = section.getAttribute('data-group-code') || '';
        var match = (query === '' || code.indexOf(query) !== -1);
        section.style.display = match ? '' : 'none';
        if(match && query !== ''){
            var body = section.querySelector('.group-body');
            if(body) body.style.display = 'block';
            var chevron = section.querySelector('.chevron');
            if(chevron) chevron.textContent = '▾';
        }
    });
}
</script>
</body>
</html>
<?php /**PATH /home/thelomzn/fypms/resources/views/faculty/phase-evaluation.blade.php ENDPATH**/ ?>