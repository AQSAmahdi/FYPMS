<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
 
class SupervisorProfile extends Model
{
    protected $fillable = [
        'user_id','employee_id','contact',
        'designation','department_id','max_groups','status'
    ];
 
    public function user()       { return $this->belongsTo(User::class); }
    public function department() { return $this->belongsTo(Department::class); }
}