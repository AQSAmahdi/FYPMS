<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class SystemSetting extends Model
{
    protected $fillable = ['key','value'];

    public static function get($key, $default = null)
    {
        $setting = self::where('key', $key)->first();
        return $setting ? $setting->value : $default;
    }

    public static function set($key, $value)
    {
        self::updateOrCreate(['key'=>$key],['value'=>$value]);
    }

    public static function isGroupFormationOpen()
    {
        if (self::get('group_formation_open') != '1') return false;
        $deadline = self::get('group_formation_deadline');
        if ($deadline && now()->gt($deadline)) return false;
        return true;
    }
}
