<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('defence_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('fyp_group_id')->constrained('fyp_groups')->onDelete('cascade');
            $table->foreignId('defence_panel_id')->constrained('defence_panels')->onDelete('cascade');
            $table->foreignId('assigned_teacher_id')->constrained('users')->onDelete('cascade');
            $table->date('defence_date');
            $table->time('defence_time');
            $table->string('room');
            $table->enum('status', ['scheduled','completed','cancelled'])->default('scheduled');
            $table->foreignId('created_by')->constrained('users');
            $table->timestamps();
        });
    }
    public function down() { Schema::dropIfExists('defence_schedules'); }
};
