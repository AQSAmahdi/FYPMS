<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
  public function up(): void
{
    Schema::create('fyp_phases', function (Blueprint $table) {
        $table->id();
        $table->string('name');                    // "Mid Defence", "Final Defence"
        $table->text('description')->nullable();
        $table->unsignedInteger('total_marks');    // jaise 500
        $table->unsignedInteger('convert_to_marks'); // jaise 200
        $table->foreignId('session_id')->nullable()->constrained('sessions')->nullOnDelete();
        $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
        $table->enum('shift', ['Morning', 'Evening'])->nullable();
        $table->boolean('is_active')->default(true);
        $table->unsignedInteger('order')->default(1);
        $table->foreignId('created_by')->constrained('users')->cascadeOnDelete();
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('fyp_phases');
}
};
