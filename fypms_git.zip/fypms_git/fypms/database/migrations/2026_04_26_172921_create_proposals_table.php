<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('proposals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('fyp_group_id')->constrained('fyp_groups')->onDelete('cascade');
            $table->string('title');
            $table->text('description');
            $table->string('technology_stack')->nullable();
            $table->string('file_path')->nullable();
            $table->enum('status', ['pending','approved','rejected'])->default('pending');
            $table->text('focal_remarks')->nullable();
            $table->timestamps();
        });
    }
    public function down() { Schema::dropIfExists('proposals'); }
};
