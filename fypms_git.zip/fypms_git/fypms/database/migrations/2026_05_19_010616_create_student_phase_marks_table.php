<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
   public function up(): void
{
    Schema::create('student_phase_marks', function (Blueprint $table) {
        $table->id();
        $table->foreignId('phase_id')->constrained('fyp_phases')->cascadeOnDelete();
        $table->foreignId('phase_schedule_id')->constrained('phase_schedules')->cascadeOnDelete();
        $table->foreignId('student_id')->constrained('users')->cascadeOnDelete();
        $table->foreignId('evaluator_id')->constrained('users')->cascadeOnDelete();
        $table->string('criteria_name');           // criteria ka naam
        $table->unsignedInteger('max_marks');      // is criteria ke max marks
        $table->decimal('marks_obtained', 8, 2);  // teacher ne diye
        $table->decimal('converted_marks', 8, 2)->nullable(); // auto calculate
        $table->timestamps();

        // Ek evaluator ek student ko ek criteria mein ek baar mark kare
        $table->unique(['phase_schedule_id', 'student_id', 'evaluator_id', 'criteria_name'], 'unique_student_mark');
    });
}

public function down(): void
{
    Schema::dropIfExists('student_phase_marks');
}
};
