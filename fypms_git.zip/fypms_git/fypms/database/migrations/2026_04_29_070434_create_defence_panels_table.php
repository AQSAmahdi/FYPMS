<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('defence_panels', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->foreignId('created_by')->constrained('users');
            $table->enum('status', ['active','inactive'])->default('active');
            $table->timestamps();
        });
    }
    public function down() { Schema::dropIfExists('defence_panels'); }
};
