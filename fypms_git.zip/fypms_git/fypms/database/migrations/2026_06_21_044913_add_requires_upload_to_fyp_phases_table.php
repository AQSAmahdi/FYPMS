<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('fyp_phases', function (Blueprint $table) {
            $table->boolean('requires_upload')->default(false)->after('description');
            $table->text('upload_instructions')->nullable()->after('requires_upload');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('fyp_phases', function (Blueprint $table) {
            $table->dropColumn(['requires_upload', 'upload_instructions']);
        });
    }
};
