<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
{
    Schema::create('student_profiles', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->onDelete('cascade');
        $table->string('student_id')->unique();
        $table->string('reg_no')->nullable()->unique();
        $table->string('contact')->nullable();
        $table->foreignId('department_id')->constrained()->onDelete('cascade');
        $table->foreignId('session_id')->constrained('academic_sessions')->onDelete('cascade');
        $table->foreignId('batch_id')->constrained()->onDelete('cascade');
        $table->integer('current_semester')->default(1);
        $table->enum('shift', ['Morning', 'Evening'])->default('Morning');
        $table->timestamps();
    });
}

    public function down()
    {
        Schema::dropIfExists('student_profiles');
    }
};
