<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('fyp_attendances', function (Blueprint $table) {
            $table->foreignId('meeting_id')->nullable()->after('group_id')->constrained('meeting_schedules')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('fyp_attendances', function (Blueprint $table) {
            $table->dropForeign(['meeting_id']);
            $table->dropColumn('meeting_id');
        });
    }
};
