<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('phase_schedules', function (Blueprint $table) {
            $table->unsignedTinyInteger('attempt_number')->default(1)->after('status');
            $table->enum('result', ['pending', 'pass', 'fail'])->default('pending')->after('attempt_number');
            $table->text('result_remarks')->nullable()->after('result');
            $table->decimal('average_marks', 8, 2)->nullable()->after('result_remarks');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('phase_schedules', function (Blueprint $table) {
            $table->dropColumn(['attempt_number', 'result', 'result_remarks', 'average_marks']);
        });
    }
};
