<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Track late upload info on each document
        Schema::table('phase_documents', function (Blueprint $table) {
            $table->boolean('is_late')->default(false)->after('file_size');
            $table->timestamp('uploaded_at')->nullable()->after('is_late');
        });

        // Track privilege grant on each schedule
        Schema::table('phase_schedules', function (Blueprint $table) {
            $table->date('upload_deadline')->nullable()->after('schedule_date');
            $table->boolean('late_upload_allowed')->default(false)->after('upload_deadline');
            $table->foreignId('late_upload_allowed_by')->nullable()->constrained('users')->nullOnDelete()->after('late_upload_allowed');
            $table->timestamp('late_upload_allowed_at')->nullable()->after('late_upload_allowed_by');
        });
    }

    public function down(): void
    {
        Schema::table('phase_documents', function (Blueprint $table) {
            $table->dropColumn(['is_late', 'uploaded_at']);
        });
        Schema::table('phase_schedules', function (Blueprint $table) {
            $table->dropColumn(['upload_deadline', 'late_upload_allowed', 'late_upload_allowed_by', 'late_upload_allowed_at']);
        });
    }
};
