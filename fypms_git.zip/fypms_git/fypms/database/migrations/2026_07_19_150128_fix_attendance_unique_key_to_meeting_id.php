<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('fyp_attendances', function (Blueprint $table) {
            $table->dropUnique('unique_attendance_entry');
            $table->unique(['student_id', 'meeting_id'], 'unique_attendance_meeting_entry');
        });
    }

    public function down(): void
    {
        Schema::table('fyp_attendances', function (Blueprint $table) {
            $table->dropUnique('unique_attendance_meeting_entry');
            $table->unique(['group_id', 'student_id', 'meeting_date'], 'unique_attendance_entry');
        });
    }
};
