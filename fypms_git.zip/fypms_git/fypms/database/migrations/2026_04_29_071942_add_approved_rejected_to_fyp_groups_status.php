<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up() {
        DB::statement("ALTER TABLE fyp_groups MODIFY COLUMN status ENUM('open','locked','proposal_submitted','supervisor_assigned','approved','rejected') DEFAULT 'open'");
    }
    public function down() {
        DB::statement("ALTER TABLE fyp_groups MODIFY COLUMN status ENUM('open','locked','proposal_submitted','supervisor_assigned') DEFAULT 'open'");
    }
};
