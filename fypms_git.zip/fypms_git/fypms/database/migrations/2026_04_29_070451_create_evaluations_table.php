<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('evaluations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('defence_schedule_id')->constrained('defence_schedules')->onDelete('cascade');
            $table->foreignId('evaluated_by')->constrained('users')->onDelete('cascade');
            $table->foreignId('criteria_id')->constrained('evaluation_criteria')->onDelete('cascade');
            $table->integer('marks_obtained');
            $table->timestamps();
            $table->unique(['defence_schedule_id','evaluated_by','criteria_id']);
        });
    }
    public function down() { Schema::dropIfExists('evaluations'); }
};
