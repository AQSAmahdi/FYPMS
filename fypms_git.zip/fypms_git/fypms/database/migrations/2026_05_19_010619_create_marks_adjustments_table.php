<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up(): void
{
    Schema::create('marks_adjustments', function (Blueprint $table) {
        $table->id();
        $table->foreignId('phase_id')->constrained('fyp_phases')->cascadeOnDelete();
        $table->foreignId('student_id')->constrained('users')->cascadeOnDelete();
        $table->decimal('total_converted_marks', 8, 2); // system ne calculate kiya
        $table->decimal('adjusted_marks', 8, 2);        // focal ne change kiya
        $table->text('reason')->nullable();
        $table->foreignId('adjusted_by')->constrained('users')->cascadeOnDelete();
        $table->timestamp('adjusted_at')->useCurrent();
        $table->timestamps();

        $table->unique(['phase_id', 'student_id']); // per phase per student ek adjustment
    });
}

public function down(): void
{
    Schema::dropIfExists('marks_adjustments');
}
};
