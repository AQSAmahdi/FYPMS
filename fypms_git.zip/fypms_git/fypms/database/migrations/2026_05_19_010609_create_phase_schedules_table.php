<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
   public function up(): void
{
    Schema::create('phase_schedules', function (Blueprint $table) {
        $table->id();
        $table->foreignId('phase_id')->constrained('fyp_phases')->cascadeOnDelete();
        $table->foreignId('group_id')->constrained('fyp_groups')->cascadeOnDelete();
        $table->foreignId('panel_id')->nullable()->constrained('defence_panels')->nullOnDelete();
        $table->date('schedule_date');
        $table->time('schedule_time');
        $table->string('room')->nullable();
        $table->enum('status', ['scheduled', 'completed', 'cancelled'])->default('scheduled');
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('phase_schedules');
}
};
