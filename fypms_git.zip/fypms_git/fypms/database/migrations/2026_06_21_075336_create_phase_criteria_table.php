<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('phase_criteria', function (Blueprint $table) {
            $table->id();
            $table->foreignId('phase_id')->constrained('fyp_phases')->cascadeOnDelete();
            $table->string('name');
            $table->unsignedInteger('max_marks');
            $table->unsignedInteger('order')->default(1);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('phase_criteria');
    }
};
