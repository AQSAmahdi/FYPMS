<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('defence_schedules', function (Blueprint $table) {
            $table->enum('result', ['pending', 'pass', 'fail'])->default('pending')->after('status');
            $table->text('result_remarks')->nullable()->after('result');
        });
    }
    public function down(): void {
        Schema::table('defence_schedules', function (Blueprint $table) {
            $table->dropColumn(['result', 'result_remarks']);
        });
    }
};
