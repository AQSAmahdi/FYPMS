<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('group_join_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('fyp_group_id')->constrained('fyp_groups')->onDelete('cascade');
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->enum('status', ['pending','accepted','rejected'])->default('pending');
            $table->timestamps();
        });
    }
    public function down() { Schema::dropIfExists('group_join_requests'); }
};
