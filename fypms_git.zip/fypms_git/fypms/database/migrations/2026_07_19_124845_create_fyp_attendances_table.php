<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('fyp_attendances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('group_id')->constrained('fyp_groups')->cascadeOnDelete();
            $table->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('marked_by')->constrained('users')->cascadeOnDelete();
            $table->date('meeting_date');
            $table->enum('status', ['present', 'absent', 'late'])->default('present');
            $table->string('remarks')->nullable();
            $table->timestamps();

            // Ek group ke ek student ka ek din mein sirf ek attendance record ho
            $table->unique(['group_id', 'student_id', 'meeting_date'], 'unique_attendance_entry');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('fyp_attendances');
    }
};
