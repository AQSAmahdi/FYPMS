<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('phase_documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('phase_id')->constrained('fyp_phases')->cascadeOnDelete();
            $table->foreignId('group_id')->constrained('fyp_groups')->cascadeOnDelete();
            $table->foreignId('phase_schedule_id')->nullable()->constrained('phase_schedules')->nullOnDelete();
            $table->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('original_filename');
            $table->string('stored_path');
            $table->string('file_type', 10)->nullable();
            $table->unsignedBigInteger('file_size')->nullable();
            $table->timestamps();
            $table->unique(['phase_id', 'group_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('phase_documents');
    }
};
