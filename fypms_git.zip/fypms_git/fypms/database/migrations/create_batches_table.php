<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
   public function up()
{
    Schema::create('batches', function (Blueprint $table) {
        $table->id();
        $table->string('name'); // e.g. Fall 2021
        $table->foreignId('department_id')->constrained()->onDelete('cascade');
        $table->boolean('is_active')->default(true);
        $table->timestamps();
    });
}

    public function down()
    {
        Schema::dropIfExists('batches');
    }
};
