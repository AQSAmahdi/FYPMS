<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('fyp_groups', function (Blueprint $table) {
            $table->id();
            $table->string('group_code')->unique();
            $table->string('project_title')->nullable();
            $table->text('project_description')->nullable();
            $table->foreignId('department_id')->constrained('departments');
            $table->foreignId('session_id')->constrained('academic_sessions');
            $table->string('shift');
            $table->foreignId('created_by')->constrained('users');
            $table->unsignedBigInteger('supervisor_id')->nullable();
            $table->enum('status', ['open','locked','proposal_submitted','supervisor_assigned'])->default('open');
            $table->integer('max_members')->default(4);
            $table->timestamps();
        });
    }
    public function down() { Schema::dropIfExists('fyp_groups'); }
};
