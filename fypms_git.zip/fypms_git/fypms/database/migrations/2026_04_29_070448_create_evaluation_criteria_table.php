<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('evaluation_criteria', function (Blueprint $table) {
            $table->id();
            $table->foreignId('defence_schedule_id')->constrained('defence_schedules')->onDelete('cascade');
            $table->string('criteria_name');
            $table->integer('max_marks');
            $table->integer('order')->default(0);
            $table->timestamps();
        });
    }
    public function down() { Schema::dropIfExists('evaluation_criteria'); }
};
