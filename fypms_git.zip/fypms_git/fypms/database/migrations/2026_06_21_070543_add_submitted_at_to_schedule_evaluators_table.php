<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('schedule_evaluators', function (Blueprint $table) {
            $table->timestamp('submitted_at')->nullable()->after('evaluator_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('schedule_evaluators', function (Blueprint $table) {
            $table->dropColumn('submitted_at');
        });
    }
};
