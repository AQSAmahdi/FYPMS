<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class AdminSeeder extends Seeder
{
    public function run()
    {
        User::create([
            'name'     => 'Focal Person',
            'email'    => 'focal@theluna.online',
            'password' => Hash::make('focalperson'),
            'role'     => 'focal_person',
        ]);
    }
}