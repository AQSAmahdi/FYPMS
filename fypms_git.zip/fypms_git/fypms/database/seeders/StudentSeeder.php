<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class StudentSeeder extends Seeder
{
    public function run()
    {
        User::create([
            'name'     => 'Test Student',
            'email'    => 'student@theluna.online',
            'password' => Hash::make('student'),
            'role'     => 'student',
        ]);
    }
}