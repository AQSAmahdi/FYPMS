<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DepartmentSeeder extends Seeder
{
    public function run()
    {
        $departments = [
            ['name' => 'Computer Science',      'code' => 'CS',  'is_active' => true],
            ['name' => 'Information Technology', 'code' => 'IT',  'is_active' => true],
            ['name' => 'Artificial Intelligence','code' => 'AI',  'is_active' => true],
            ['name' => 'Data Science',           'code' => 'DS',  'is_active' => true],
            ['name' => 'Software Engineering',   'code' => 'SE',  'is_active' => true],
        ];

        foreach ($departments as $dept) {
            DB::table('departments')->insert(array_merge($dept, [
                'created_at' => now(),
                'updated_at' => now(),
            ]));
        }
    }
}
