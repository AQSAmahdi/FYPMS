<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class SupervisorSeeder extends Seeder
{
    public function run()
    {
        User::create([
            'name'     => 'Test Supervisor',
            'email'    => 'supervisor@theluna.online',
            'password' => Hash::make('supervisor'),
            'role'     => 'supervisor',
        ]);
    }
}